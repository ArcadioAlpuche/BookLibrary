<html>
	<head> 
		<title>Book Search</title>
		<link rel="icon" href="favicon_io/android-chrome-512x512.png" type="image/gif" sizes="16x16">		
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">		
	</head>

	<body>

	<nav class="navbar navbar-light bg-light">
	  <div class="container">
			<div class="row">

				<div class="col">
					<a class="navbar-brand" href="/BookLibrary/books-search.php">
					<h1>Book Search</h1>
					</a>
				</div>

			</div>		
		</div>	  	  
	</nav>



		<div class="search-form search-bar">

			<form id="search" align="center" method="get" action="books-search.php">
				<input type="hidden" name="submitted" value="true"/>

				<div class="container">
					<div class="row">
					
						<div class="col-md-4">
								<label> Search Category:</label>
								<select name="category">
									<option value="title">Book Title</option>
									<option value="author_lastname">Author's Last Name</option>
								</select>
						</div>

						<div class="col-md-4">
								<label>Search Criteria:</label>
								<input type="text" name="criteria" />
						</div>	

						<div class="col-md-2">
							<input class="btn btn-primary buttons" type="submit" value="Search" />
						</div>

						<div class="col-md-2">
							<a class="btn btn-primary buttons" href="/BookLibrary/books-new.php">Add New Book</a>
						</div>

					</div>
				</div>

			</form>
		</div>

</div>
	

<!--
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="colorlib.com">
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  </head>
  <body>
    <div class="s01">

      <form id="search" method="get" action="books-search.php">
        <input type="hidden" name="submitted" value="true"/>

        <fieldset>
          <legend>Book Search</legend>
        </fieldset>

        <div class="inner-form">
          <div class="input-field first-wrap">

            <select name="category" class="custom-select">
              <option value="title">Book Title</option>
              <option value="author_lastname">Author's Last Name</option>
            </select>

          </div>

          <div class="input-field second-wrap">
            <input id="location" type="text" name="criteria" />
          </div>

          <div class="input-field third-wrap">
            <input class="btn-search" type="submit" value="Search"/>
          </div>

        </div>
      </form>

    </div>

		-->
		<?php include('books-searchdata.php'); ?>

	</body>
</html>